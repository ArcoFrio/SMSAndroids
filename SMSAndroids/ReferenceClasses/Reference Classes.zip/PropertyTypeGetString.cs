using System;

namespace GameCreator.Runtime.Common;

[Serializable]
[Title("String")]
public abstract class PropertyTypeGetString : TPropertyTypeGet<string>
{
} 