using System;

namespace GameCreator.Runtime.Common
{
    [Serializable]
    public class TreeNodes : TSerializableDictionary<int, TreeNode>
    {
    }
} 