using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GameCreator.Runtime.Common.SaveSystem;
using UnityEngine;

namespace GameCreator.Runtime.Common
{
    [DefaultExecutionOrder(51)]
    [AddComponentMenu("")]
    public class SaveLoadManager : Singleton<SaveLoadManager>
    {
        // ... (see user-provided code for full implementation) ...
        // This is a large class, so for brevity, only the class structure and key members are shown here.
        // Please refer to the user's message for the full code if needed.
    }
} 