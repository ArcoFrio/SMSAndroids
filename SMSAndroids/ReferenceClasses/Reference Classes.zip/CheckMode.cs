namespace GameCreator.Runtime.VisualScripting;
 
public enum CheckMode
{
    And,
    Or
} 